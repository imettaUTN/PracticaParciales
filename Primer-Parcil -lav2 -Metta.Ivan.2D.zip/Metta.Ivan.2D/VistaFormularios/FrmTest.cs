﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades;
namespace VistaFormularios
{
    public partial class FrmTest : Form
    {
        public Vendedor vendedor;
        public FrmTest( Vendedor v)
        {
            InitializeComponent();
            this.vendedor = v;
        }

        private void FrmTest_Load(object sender, EventArgs e)
        {
            //cargo datos harcodeados de publicaciones
            Biografia p1 = (Biografia)"Life (Keith Richards)";
            Biografia p2 = new Biografia("White line fever (Lemmy)", 5);
            Biografia p3 = new Biografia("Commando (Johnny Ramone)", 2, 5000);
            Comic p4 = new Comic("La Muerte de Superman (Superman)", true, 1, 1850);
            Comic p5 = new Comic("Año Uno (Batman)", false, 3, 1270);
            lstStock.Items.Add(p1);
            lstStock.Items.Add(p2);
            lstStock.Items.Add(p3);
            lstStock.Items.Add(p4);
            lstStock.Items.Add(p5);

        }

        
        private void btnVender_Click(object sender, EventArgs e)
        {
            Publicacion publiVta = (Publicacion)lstStock.SelectedItem;
            if (vendedor + publiVta)
            {
                MessageBox.Show("Venta de " + publiVta + " exitosa");
            }
            else
            {
                MessageBox.Show("Venta de " + publiVta + " no se pudo realizar");
            }
        }

        private void btnVerInforme_Click(object sender, EventArgs e)
        {
            rtbInforme.Text = Vendedor.InformeDeVentas(this.vendedor);
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("¿Esta seguro que desea salir del formulario?", "Cierre de formulario", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Close();
            }
        }
    }
}
