﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public abstract class Publicacion
    {
        protected float importe;
        protected string nombre;
        protected int stock;

        /// <summary>
        /// Contructor Publicacion con nombre
        /// </summary>
        /// <param name="nombre"> Nombre publicacion </param>
        public Publicacion(string nombre)
        {
            this.nombre = nombre;
        }

        /// <summary>
        ///  Contructor Publicacion con nombre y stock
        /// </summary>
        /// <param name="nombre"> nombre publicacion </param>
        /// <param name="stock"> stock publicacion </param>
        public Publicacion(string nombre, int stock) : this(nombre)
        {
            this.stock = stock;
        }
        /// <summary>
        ///  Contructor Publicacion con nombre, stock e importe
        /// </summary>
        /// <param name="nombre"> nombre publicacion </param>
        /// <param name="stock"> stock publicacion </param>
        /// <param name="importe"> importe publicacion </param>
        public Publicacion(string nombre, int stock, float importe): this(nombre,stock)
        {
            this.importe = importe;
        }

        /// <summary>
        /// Indica si es color la publicacion
        /// </summary>
        protected abstract bool EsColor { get; }


        /// <summary>
        /// Indica si hay stock de la publicacion
        /// </summary>
        public virtual bool HayStock
        {
            get { return this.stock >= 0; }
        }


        /// <summary>
        /// Indica el importe de la publicacion
        /// </summary>
        public float Importe
        {
            get { return this.importe; }
        }

        /// <summary>
        /// Indica el stock de la publicacion
        /// </summary>
        public int Stock
        {
            get { return this.stock; }
            set
            {
                if (value > 0)
                { this.stock = value; }
            }
        }
        
        /// <summary>
        /// Muestra el informe de la publicacion
        /// </summary>
        /// <returns>informe de la publicacion</returns>
        public string Informacion()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Nombre: " + this.nombre);
            sb.AppendLine("Stock: "+ this.stock);
            sb.AppendLine("Color: " + (this.EsColor?"SI":"NO"));
            sb.AppendFormat("Valor: {0:C} \n" , this.importe );
            return sb.ToString();
        }

        /// <summary>
        /// Sobrecarga del metodo toString
        /// </summary>
        /// <returns> Nombre de la publicacion </returns>
        public override string ToString()
        {
            return this.nombre;
        }






    }
}
