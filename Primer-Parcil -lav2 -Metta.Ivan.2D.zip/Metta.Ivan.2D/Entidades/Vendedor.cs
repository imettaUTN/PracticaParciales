﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Vendedor
    {
        private string nombre;
        private List<Publicacion> ventas;

        /// <summary>
        /// Contructor por defecto de venta
        /// </summary>
        private Vendedor()
        {
            ventas = new List<Publicacion>();
        }
        /// <summary>
        /// Contructor por venta , recib nombre
        /// </summary>
        /// <param name="nombre">Nombre vendedor</param>
        public Vendedor(string nombre): this()
        {
            this.nombre = nombre;
        }
        /// <summary>
        /// Suma una venta de una publicacion al vendedor
        /// </summary>
        /// <param name="v"> venta</param>
        /// <param name="p"> publicacion a vender</param>
        /// <returns> Se hizo la venta?</returns>
        public static bool operator +(Vendedor v, Publicacion p)
        {
            if(p.HayStock)
            {
                v.ventas.Add(p);
                p.Stock -= 1;
                return true;
            }
            return false;
        }
        /// <summary>
        /// Informe de las ventas realizadas por un vendedor
        /// </summary>
        /// <param name="v"> vendedor </param>
        /// <returns> Informe de las ventas </returns>
        public static string InformeDeVentas(Vendedor v)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(v.nombre);
            sb.AppendLine("-----------------------------------------------------------------------");
            float ganancia =0;
            foreach(Publicacion publi in v.ventas)
            {
                sb.AppendLine(publi.Informacion());
                sb.AppendLine("-----------------------------------------------------------------------");
                ganancia += publi.Importe;
            }
            sb.AppendLine("Ganancia Total : $" + ganancia);
            return sb.ToString();
        }

    }
}
