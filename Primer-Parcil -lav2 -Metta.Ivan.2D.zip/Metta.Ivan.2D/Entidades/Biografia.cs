﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Biografia : Publicacion
    {
        /// <summary>
        /// Contructor biogrfia con nombre de la misma
        /// </summary>
        /// <param name="name">Nombre biografia </param>
        public Biografia(string name) : base(name)
        { }

        /// <summary>
        ///  Contructor biogrfia con nombre, stock de la misma
        /// </summary>
        /// <param name="name">nombre biografia</param>
        /// <param name="stock"> stock biografia </param>
        public Biografia(string name,int stock) : base(name, stock)
        { }

        /// <summary>
        ///  Contructor biogrfia con nombre, stock, valor de la misma
        /// </summary>
        /// <param name="name"> Nombre biografia </param>
        /// <param name="stock"> stock biografia </param>
        /// <param name="valor"> valor biografia </param>
        public Biografia(string name, int stock, float valor) : base(name,stock,valor)
        { }

        /// <summary>
        /// Indica si la biografia es de color
        /// </summary>
        protected override bool EsColor
        {
            get { return false; }
        }

        //Indica si hay stock de la biografia
        public override bool HayStock
        {
            get { return Stock >0; }
        }

        /// <summary>
        /// Instancia un nuevo objeto de la biografia con el nombre de la misma
        /// </summary>
        /// <param name="nombre">Nombre biografia </param>
        public static explicit  operator Biografia(string nombre)
        {
            return new Biografia(nombre);
        }
    }
}
