﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Comic : Publicacion
    {
        private bool esColor;
        /// <summary>
        /// Contructor comic con parametro nombre, stock, valor, y si es color
        /// </summary>
        /// <param name="nombre"> Nombre Comic </param>
        /// <param name="esColor"> Es de color el comic ?</param>
        /// <param name="stock"> stock comic </param>
        /// <param name="valor"> valor comic </param>
        public Comic(string nombre, bool esColor, int stock, float valor) :base(nombre,stock,valor)
        {
            this.esColor = esColor;
        }

        /// <summary>
        /// Indica si el comic es de color
        /// </summary>
        protected override bool EsColor
        {
            get { return esColor; }
        }
    }
}
